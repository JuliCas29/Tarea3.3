const express = require('express')
const { validarProducto } = require('./schemas/product')
const db = require('./db')



const app = express()
const PORT = process.env.PORT || 3000


app.use(express.json())


app.get('/productos', (request, response) => {
    response.json(productos)
})

app.get('/productos/:id', (request, response) => {

    const { id } = request.params

    const productoId = Number(id)

    if (!productoId) {
        response.status(400).json({ error: true, message: 'Parametros invalidos' })
    }

    const producto = productos.filter(({ id }) => id === productoId)

    response.json(producto)
})

app.post('/productos', (req, res) => {

    
    let data = req.body 


    const validacion = validarProducto(data)

    if (validacion.success) {
        //agregar a la BBDDD

        data = {
            id: Date.now(), //generar un id unico, viene de la BBDD
            ...data
        }

        productos.unshift(data)
        res.status(201).json(productos)
    } else {
        res.status(400).json({
            error: true,
            message: 'Datos invalidos'
        })
    }
})


app.put('/productos/:id', (req, res) => {

    

})


app.use((req, res, next) => {

    res.status(404).json({
        error: true,
        message: `La ruta '${req.url}' no existe`
    })
})

app.listen(PORT, () => {
    console.log(`Server on port http://localhost:${PORT}`)
})

